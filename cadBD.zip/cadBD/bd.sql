select * from tb_clientes
