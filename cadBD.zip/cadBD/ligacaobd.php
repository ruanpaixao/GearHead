<?php
$servername = "localhost/cadBD/gearhead01_tb_clientes.sql"; // endereço do servidor MySQL
$username = "admin"; // seu nome no Mysql
$password = ""; 
$dbname = "gearhead01"; 

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Falha na conexão". $conn->connect_error);
}

$nome = $_POST["nome"];
$cpf = $_POST["cpf"];
$email = $_POST["email"];

$sql = "INSERT INTO tb_clientes ( nome, cpf, email) VALUES ( '$nome', '$cpf', '$email')";

// Executa a consulta SQL
if ($conn->query($sql) === TRUE) {
    echo "Pedido enviado com sucesso!";
} else {
    echo "Erro ao enviar o pedido: " . $conn->error;
}

// Fecha a conexão com o banco de dados
$conn->close();
?>












?>